package Enums;

/**
 * Dylan Bannon <drb2857@rit.edu>
 */
public enum MpaaRating {
    G,
    PG,
    PG_13,
    R,
    NC_17,
    TV_MA,
    TV_PG;
}
