#!/bin/bash
sh ./makejar.sh
cd src/main/web-app
npm install
cd ../../..